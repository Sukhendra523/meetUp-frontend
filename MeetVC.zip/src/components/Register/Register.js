import React from 'react';
import img1 from '../Login/image1.jpg';
import img2 from '../Login/image2.jpg';
import '../Login/Login.css'

function Register() {
    return (
        <>
            <section class="wrapper">
        <div class="container mx-auto">
            <div class="row">
                <div class="col-lg-10 offset-1">
                    <div class="row g-0">
                        <div class="col-lg-6 col-md-6">
                            <div class="card register-card">
                                <div class="top">
                                    <form action="">
                                        <div class="input-group flex-nowrap mb-3">
                                            <span class="input-group-text" id="addon-wrapping"><i class="fa fa-user"></i></span>
                                            <input type="username" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="addon-wrapping" required/>
                                        </div>
                                        <div class="input-group flex-nowrap my-3">
                                            <span class="input-group-text" id="addon-wrapping"><i class="fa fa-envelope"></i></span>
                                            <input type="email" class="form-control" placeholder="Email" aria-label="Email" aria-describedby="addon-wrapping" required/>
                                        </div>
                                        <div class="input-group flex-nowrap my-3">
                                            <span class="input-group-text" id="addon-wrapping"><i class="fa fa-phone-alt"></i></span>
                                            <input type="tel" class="form-control" placeholder="Phone Number" aria-label="Email" aria-describedby="addon-wrapping" required/>
                                        </div>
                                        <div class="input-group flex-nowrap my-3">
                                            <span class="input-group-text" id="addon-wrapping"><i class="fa fa-key"></i></span>
                                            <input type="password" class="form-control" placeholder="Password" aria-label="Password" aria-describedby="addon-wrapping" required/>
                                        </div>
                                        <div class="input-group flex-nowrap my-3">
                                            <span class="input-group-text" id="addon-wrapping"><i class="fa fa-key"></i></span>
                                            <input type="password" class="form-control" placeholder="Confirm Password" aria-label="Password" aria-describedby="addon-wrapping" required/>
                                        </div>

                                        <div class="d-flex justify-content-between align-items-center my-3">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault"/>
                                                <label class="form-check-label" for="flexCheckDefault">
                                              Remember me
                                            </label>
                                            </div>
                                            <div class="btn btn-primary">Register</div>
                                        </div>
                                    </form>
                                </div>
                                <div class="text-center divider">
                                    <p class="bar">or</p>
                                </div>
                                <div class="bottom">
                                    <div class="btn-group my-2" role="group" aria-label="Basic example">
                                        <div class="fb small-btn"><i class="fab fa-facebook-square"></i></div>
                                        <button type="button" class="btn facebook">Login with Facebook</button>
                                    </div>
                                    <div class="btn-group  my-2" role="group" aria-label="Basic example">
                                        <div class="small-btn tw"><i class="fab fa-twitter"></i></div>
                                        <button type="button" class="btn twitter">Login with Twitter</button>
                                    </div>
                                    <div class="btn-group  my-2" role="group" aria-label="Basic example">
                                        <div class="small-btn G "><i class="fab fa-google"></i></div>
                                        <button type="button" class="btn google">Login with Google</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="card-1 border-0 register-card">
                                <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
                                    <div class="carousel-indicators">
                                        <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                                        <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
                                    </div>
                                    <div class="carousel-inner">
                                        <div class="carousel-item active" data-bs-interval="10000">
                                            <img src={img1} alt="..."/>
                                        </div>
                                        <div class="carousel-item" data-bs-interval="2000">
                                            <img src={img2} alt="..."/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
        </>
    )
};

export default Register;
