import React from "react";
import Navbar from "../UI/Navbar";

const MeetingFeatures = () => {
  return (
    <>
      <Navbar />
      <div>Meeting Features</div>
    </>
  );
};

export default MeetingFeatures;
