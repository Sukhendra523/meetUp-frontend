// export const SOCKETURL = "http://localhost:8080";
export const SOCKETURL = "http://ec2-18-222-98-43.us-east-2.compute.amazonaws.com:8080/";
export const JITSIURL = "beta.meet.jit.si";