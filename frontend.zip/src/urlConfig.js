export const API = "http://ec2-18-222-98-43.us-east-2.compute.amazonaws.com:2000/api";

// export const API = "http://localhost:2000/api";
