export const API =
  "http://ec2-18-217-239-68.us-east-2.compute.amazonaws.com:2000/api";
