import React from "react";

const LoginWithBottonsContainer = () => {
  return <div></div>;
};

export default LoginWithBottonsContainer;
